/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MINEDUCYT
 */


public class recurso {
    private int idRecurso;
    private String titulo;
    private int idClasificacion;
    private String idCasaEditorial;
    private String tipo;
    private int cantidadDisponible;
    private String ubicacionFisica;

    // Constructor, getters y setters
}
