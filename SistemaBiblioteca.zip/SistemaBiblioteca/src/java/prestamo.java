/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MINEDUCYT
 */

import java.util.Date;

public class prestamo {
    private int idPrestamo;
    private int idUsuario;
    private int idRecurso;
    private Date fechaPrestamo;
    private Date fechaDevolucion;

    // Constructor, getters y setters
}

